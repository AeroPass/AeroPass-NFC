export class CreateAuditoriaDto {}

